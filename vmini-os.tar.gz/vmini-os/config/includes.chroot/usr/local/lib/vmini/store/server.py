#!/usr/bin/env python3
"""vMini App Store backend (stdlib only). Binds to 127.0.0.1:7788.
Catalog types: apt | dmg | appimage | bundle (pre-wrapped tar.gz with wrapper.json)."""
import json, os, hashlib, subprocess, threading, urllib.request, uuid, shutil, tarfile, tempfile, re
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path

HERE = Path(__file__).parent
CATALOG = Path(os.environ.get("VMINI_CATALOG", "/usr/share/vmini/store/catalog.json"))
STATE = Path.home() / ".local/share/vmini/store-installed.json"
APPDIR = Path.home() / "Applications"
JOBS = {}

def load_catalog():  return json.loads(CATALOG.read_text())["apps"]
def load_state():    return json.loads(STATE.read_text()) if STATE.exists() else {}
def save_state(s):   STATE.parent.mkdir(parents=True, exist_ok=True); STATE.write_text(json.dumps(s, indent=2))

def write_desktop(app_id, name, exec_, icon="application-x-executable"):
    d = Path.home() / ".local/share/applications"; d.mkdir(parents=True, exist_ok=True)
    p = d / f"store-{app_id}.desktop"
    p.write_text(f"[Desktop Entry]\nType=Application\nName={name}\nExec={exec_}\nIcon={icon}\nCategories=X-vMini-Store;\n")
    return p

def download(url, dest, sha256, job):
    if not sha256 or sha256.upper().startswith("REPLACE"):
        raise RuntimeError("Catalog entry has no sha256 — refusing to install unverified download.")
    h = hashlib.sha256()
    with urllib.request.urlopen(url, timeout=30) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0); got = 0
        while chunk := r.read(1 << 16):
            f.write(chunk); h.update(chunk); got += len(chunk)
            if total: job["progress"] = int(got * 100 / total)
    if h.hexdigest() != sha256.lower():
        os.remove(dest); raise RuntimeError("SHA-256 mismatch — download discarded.")

def do_install(app, dock, job):
    t, aid = app["type"], app["id"]
    job["status"] = "running"
    if t == "apt":
        subprocess.run(["sudo", "-n", "apt-get", "update", "-qq"], check=False)
        subprocess.run(["sudo", "-n", "apt-get", "install", "-y", app["package"]], check=True)
        desk = next(iter(Path("/usr/share/applications").glob(f"{app.get('desktop', app['package'])}*.desktop")), None)
    elif t == "dmg":
        dl = Path.home() / "Downloads" / f"{aid}.dmg"; dl.parent.mkdir(exist_ok=True)
        download(app["url"], dl, app.get("sha256"), job)
        subprocess.run(["vmini-dmg-install", str(dl)] + ([] if dock else ["--no-dock"]), check=True)
        desk = Path.home() / ".local/share/applications" / f"mac-{aid}.desktop"; dock = False
    elif t == "appimage":
        APPDIR.mkdir(exist_ok=True); dest = APPDIR / f"{aid}.AppImage"
        download(app["url"], dest, app.get("sha256"), job); dest.chmod(0o755)
        desk = write_desktop(aid, app["name"], str(dest))
    elif t == "bundle":
        tmp = Path(tempfile.mkdtemp()) / "pkg.tgz"
        download(app["url"], tmp, app.get("sha256"), job)
        root = Path.home() / ".local/opt" / aid; shutil.rmtree(root, ignore_errors=True); root.mkdir(parents=True)
        with tarfile.open(tmp) as tf: tf.extractall(root, filter="data")      # filter blocks path traversal
        w = json.loads((root / "wrapper.json").read_text())
        desk = write_desktop(aid, w.get("name", app["name"]), str(root / w["exec"]), str(root / w["icon"]) if w.get("icon") else "application-x-executable")
    else:
        raise RuntimeError(f"unknown type {t}")
    if dock and desk:
        subprocess.run(["vmini-dock-add", str(desk)], check=False)
    st = load_state(); st[aid] = {"type": t, "desktop": str(desk) if desk else None}; save_state(st)

def do_remove(app):
    st = load_state(); rec = st.pop(app["id"], {})
    if app["type"] == "apt":
        subprocess.run(["sudo", "-n", "apt-get", "remove", "-y", app["package"]], check=False)
    else:
        for p in (APPDIR / f"{app['id']}.AppImage", ):
            p.unlink(missing_ok=True)
        shutil.rmtree(Path.home() / ".local/opt" / app["id"], ignore_errors=True)
        shutil.rmtree(Path.home() / ".darling/Applications" / f"{app.get('bundle', app['id'])}.app", ignore_errors=True)
    if rec.get("desktop"): Path(rec["desktop"]).unlink(missing_ok=True) if "/.local/" in rec["desktop"] else None
    (Path.home() / ".config/plank/dock1/launchers" / f"{Path(rec.get('desktop') or 'x').stem}.dockitem").unlink(missing_ok=True)
    save_state(st)

def run_job(fn, *a):
    jid = uuid.uuid4().hex[:8]; job = JOBS[jid] = {"status": "queued", "progress": 0, "error": None}
    def w():
        try: fn(*a, job) if fn is do_install else fn(*a); job["status"] = "done"; job["progress"] = 100
        except Exception as e: job["status"], job["error"] = "error", str(e)
    threading.Thread(target=w, daemon=True).start(); return jid

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json"):
        b = body if isinstance(body, bytes) else json.dumps(body).encode()
        self.send_response(code); self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def _host_ok(self): return self.headers.get("Host", "").split(":")[0] in ("127.0.0.1", "localhost")
    def do_GET(self):
        if not self._host_ok(): return self._send(403, {"error": "bad host"})
        p = self.path.split("?")[0]
        if p == "/api/ping": return self._send(200, {"ok": True})
        if p == "/api/catalog":
            st = load_state()
            return self._send(200, [{**a, "installed": a["id"] in st} for a in load_catalog()])
        m = re.fullmatch(r"/api/job/(\w+)", p)
        if m: return self._send(200, JOBS.get(m[1], {"status": "unknown"}))
        f = HERE / "web" / ("index.html" if p == "/" else p.lstrip("/"))
        if f.is_file() and HERE / "web" in f.resolve().parents:
            ct = {".html": "text/html", ".js": "text/javascript", ".css": "text/css"}.get(f.suffix, "application/octet-stream")
            return self._send(200, f.read_bytes(), ct)
        self._send(404, {"error": "not found"})
    def do_POST(self):
        # Custom header forces a CORS preflight, which we never answer -> blocks drive-by POSTs from web pages
        if not self._host_ok() or self.headers.get("X-VMini") != "1": return self._send(403, {"error": "forbidden"})
        n = int(self.headers.get("Content-Length") or 0); data = json.loads(self.rfile.read(n) or b"{}")
        app = next((a for a in load_catalog() if a["id"] == data.get("id")), None)
        if not app: return self._send(404, {"error": "unknown app"})
        if self.path == "/api/install": return self._send(200, {"job": run_job(do_install, app, bool(data.get("dock", True)))})
        if self.path == "/api/remove":  return self._send(200, {"job": run_job(do_remove, app)})
        self._send(404, {"error": "not found"})

if __name__ == "__main__":
    ThreadingHTTPServer(("127.0.0.1", 7788), H).serve_forever()
