#!/usr/bin/env bash
ISO="${1:-macos_clone.iso}"
ACCEL=""; [ -w /dev/kvm ] && ACCEL="-enable-kvm -cpu host"
exec qemu-system-x86_64 $ACCEL -m 2048 -smp 2 -cdrom "$ISO" -boot d \
  -vga virtio -display gtk,gl=off -device qemu-xhci -device usb-tablet \
  -nic user,model=virtio-net-pci,hostfwd=tcp::8765-:8765
