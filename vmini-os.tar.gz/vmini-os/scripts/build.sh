#!/usr/bin/env bash
# Builds macos_clone.iso with Debian live-build.
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
[ "$(id -u)" -eq 0 ] || { echo "run as root (sudo -E ./scripts/build.sh)"; exit 1; }

SUITE="${SUITE:-trixie}"            # bookworm also works (swap 7zip -> p7zip-full in package list)
ARCH="${ARCH:-amd64}"
OUT="$ROOT/macos_clone.iso"
B="$ROOT/build"

if grep -qi "crostini\|penguin" /etc/hostname 2>/dev/null || [ ! -w /proc/sys/kernel ] ; then
  echo "WARN: this looks like a restricted container (Crostini?). live-build needs mount/loop/chroot."
  echo "      Use a full VM, 'make docker-build', or the GitHub Actions workflow."
fi

rm -rf "$B"; mkdir -p "$B"; cd "$B"

lb config \
  --distribution "$SUITE" --architectures "$ARCH" \
  --archive-areas "main contrib non-free non-free-firmware" \
  --binary-images iso-hybrid --bootloaders "grub-efi,syslinux" \
  --debian-installer none --memtest none --win32-loader false \
  --linux-flavours "$ARCH" --apt-indices false --apt-recommends false \
  --firmware-chroot true \
  --iso-application "vMini macOS-style" --iso-volume "VMINI_MAC" \
  --bootappend-live "boot=live components quiet splash username=mac hostname=vmini locales=en_US.UTF-8 keyboard-layouts=us timezone=UTC"

# Overlay our tree. Newer live-build renamed includes.chroot -> includes.chroot_after_packages,
# so ship both (idempotent copy).
rsync -a "$ROOT/config/package-lists/" config/package-lists/
rsync -a "$ROOT/config/hooks/"         config/hooks/
rsync -a "$ROOT/config/includes.chroot/" config/includes.chroot/
rsync -a "$ROOT/config/includes.chroot/" config/includes.chroot_after_packages/

# Pass build-time options into the chroot so hooks can read them
for d in config/includes.chroot config/includes.chroot_after_packages; do
  mkdir -p "$d/etc/vmini"
  cat > "$d/etc/vmini/build.env" <<ENV
DARLING_DEB_URL="${DARLING_DEB_URL:-}"
DARLING_DEB_SHA256="${DARLING_DEB_SHA256:-}"
ENV
  chmod +x "$d"/usr/local/bin/* 2>/dev/null || true
  chmod +x "$d"/usr/local/lib/vmini/store/server.py 2>/dev/null || true
done
chmod +x config/hooks/live/*.chroot

lb build 2>&1 | tee "$ROOT/build.log"

ISO_FILE="$(ls -1 ./*.iso | head -n1)"
mv "$ISO_FILE" "$OUT"
sha256sum "$OUT" | tee "$OUT.sha256"
echo "[build] OK -> $OUT"
