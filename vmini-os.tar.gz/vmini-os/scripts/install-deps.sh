#!/usr/bin/env bash
# Installs everything needed on the BUILD host (Debian 12/13 or Ubuntu 22.04+).
set -euo pipefail
[ "$(id -u)" -eq 0 ] || { echo "run as root (sudo)"; exit 1; }
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y --no-install-recommends \
  live-build debootstrap squashfs-tools xorriso mtools dosfstools \
  isolinux syslinux syslinux-common grub-pc-bin grub-efi-amd64-bin grub-common \
  rsync ca-certificates wget curl gnupg \
  dmg2img hfsutils hfsprogs icnsutils p7zip-full \
  python3 shellcheck qemu-system-x86 ovmf \
  chromium   # host copy only for previewing start page / store UI; the ISO installs its own
echo "[deps] done. Next: make build"
