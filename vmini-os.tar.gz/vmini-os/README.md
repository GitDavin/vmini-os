# vMini macOS-style Live OS — blueprint

Debian live-build ISO (`macos_clone.iso`): Openbox + picom + tint2 (top bar) + Plank (dock), Chromium locked in as the
system browser, a .dmg → Darling runtime, a local App Store, and a phone/AirDrop layer.

## Layout
```
Makefile                       make deps | build | docker-build | test | lint
scripts/{install-deps,build,test-qemu}.sh
.github/workflows/build.yml    cloud build (best path from a Chromebook)
config/
  package-lists/vmini.list.chroot          every package in the image
  hooks/live/0010..0040-*.chroot           run inside chroot: defaults, Chromium lock, Darling, Openbox buttons
  includes.chroot/                         copied verbatim into the image
    etc/skel/.config/{openbox,picom,tint2,plank,gtk-3.0}   desktop shell
    usr/share/themes/vMacOS/openbox-3/themerc               window theme
    etc/chromium/policies/managed/vmini.json                browser policy
    etc/chromium.d/vmini-lowspec                            low-spec flags
    usr/local/bin/vmini-*                                   web, store, dmg-install, dmgd, dock-add, mobiled, airdrop
    usr/local/lib/vmini/store/{server.py,web/}              App Store (HTTP :7788 + HTML/JS UI)
    usr/share/vmini/store/catalog.json                      app catalog
    usr/lib/systemd/user/vmini-*.service                    user daemons
    etc/udev/rules.d/99-vmini-mobile.rules
```

## Build
```
make deps
DARLING_DEB_URL=<url> DARLING_DEB_SHA256=<sha> make build   # Darling vars optional
make test                                                   # QEMU smoke test
```
**Chromebook note:** Crostini cannot run live-build (no mount/loop/chroot privileges). Build in a full Debian VM
(e.g. inside vMini), a cloud VM, or via the GitHub Actions workflow; download the ISO afterwards.

## vMini VM settings
Attach ISO as CD/DVD, ≥2 GB RAM, 2 vCPU, VirtIO GPU/3D if available (otherwise picom falls back to xrender and
Chromium to software rendering), enable USB passthrough for phones, bridged networking for the AirDrop page.

## Data flow: .dmg
double-click / download → `vmini-dmg-install` → `7z x` (fallback: `dmg2img` + `mount -t hfsplus`) → find `*.app`
→ copy to `~/.darling/Applications` → parse `Info.plist`, `.icns`→png → `.desktop` (`Exec=darling /Applications/X.app/Contents/MacOS/X`) → Plank pin.

## Honest limitations
* **Darling** runs x86_64 Mach-O only; CLI tools work well, GUI/Cocoa/Metal apps mostly don't. Not in Debian — you supply a
  .deb or build from source; its kernel module needs matching headers (included) and may not load in every VM.
  APFS-formatted .dmg files can't be read by hfsplus; 7z handles some. `.pkg`-only images are not handled.
* **Window buttons:** Openbox can't colour each button separately; dots are grey → red on hover.
* **Chromium "unremovable"** = Essential meta-package + apt hold. Root can still force-remove it.
* `--load-extension` theme: Chromium shows a dev-mode notice; if a newer build refuses, package the theme as a policy-installed CRX.
* **iPhone:** USB gives photo access (ifuse) and Wi-Fi AirPlay mirroring (UxPlay); remote *control* of iOS is impossible. Android gets full scrcpy mirroring + input.
* Unverified items (couldn't run a build in this sandbox): live-build option names on your exact version, Plank dconf keys,
  `pkgCacheGen::ForceEssential`. Run `make build`, read `build.log`, adjust.
* **Legal:** don't ship Apple fonts, icons, wallpapers, the Apple logo, or the name “Safari”/“macOS” in your product branding.
  Running Apple software requires you to hold the license for it. Include GPL/LGPL notices for Darling and others.
